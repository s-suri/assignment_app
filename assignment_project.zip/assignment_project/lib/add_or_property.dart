import 'package:assignment_project/models/my_models.dart';
import 'package:assignment_project/my_model_list_wrapper.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';


class AddOrProperty extends StatefulWidget {
  final int postion;
  final MyModel _model;
  const AddOrProperty(this.postion,this._model);
  @override
  _AddOrPropertyState createState() => _AddOrPropertyState();
}


class _AddOrPropertyState extends State<AddOrProperty> {

  var nameController = new TextEditingController();
  var launchSiteController = new TextEditingController();
  var _dateController = new TextEditingController();


  String launchedAt = "";
  String sortTime = "";
  double _rating = 1.0;
  DateTime? _selectedDate;

  @override
  void initState() {
    if(widget.postion != -1)
      {
        nameController.text = widget._model.name;
        launchSiteController.text = widget._model.launchSite;
        _rating = double.parse(widget._model.popularity.toString());
      }

    getTime();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.postion == -1 ? "Add Product" : "Edit Product",
        style: const TextStyle(
          color: Colors.white,
          fontSize: 20,
          fontWeight: FontWeight.w600
          ),
        ),
      ),

      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(left: 20,right:20,top: 40,bottom: 20),
          child: Container(
           width:  MediaQuery.of(context).size.width,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children:
              [
                nameEditText(),
                const SizedBox(height: 20,),
                launchSiteEditText(),
                const SizedBox(height: 30,),
                Padding(
                  padding: const EdgeInsets.only(bottom: 0.0),
                  child: GestureDetector(
                    onTap: ()
                    {
                      _selectDate(context);
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width > 500 ? 450 : MediaQuery.of(context).size.width,
                      height: 50,
                      decoration: BoxDecoration(
                        color: Colors.orangeAccent,
                        borderRadius: BorderRadius.circular(50)
                      ),
                      child: Center(
                        child:  Text("Pick LaunchTime ${_selectedDate == null ? "" : _selectedDate!.day < 10 ? "0${_selectedDate!.day.toString()}" : _selectedDate!.day.toString()}${_selectedDate ==null ? "" :  _selectedDate!.day < 10 ? "-0${_selectedDate!.month.toString()}" : "-"+ _selectedDate!.month.toString()}${_selectedDate ==null ? "" : "-"+ _selectedDate!.year.toString()}", style: const TextStyle(
                            color: Colors.black,
                          fontWeight: FontWeight.w600,
                          fontSize: 15,
                        ),),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 50,),
                propertyStarsEditText(),
                const SizedBox(height: 100,),
                AddOrEditButton(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


extension WidgetExtention on _AddOrPropertyState
{
   nameEditText()
   {
     return Container(
       width: MediaQuery.of(context).size.width > 500 ? 450 : MediaQuery.of(context).size.width,
       child: Center(
         child: TextFormField(
           controller: nameController,
           decoration: const  InputDecoration(
               focusedBorder: OutlineInputBorder(
                 borderSide: BorderSide(color: Colors.black, width: 1.0),
               ),
               enabledBorder: OutlineInputBorder(
                 borderSide: BorderSide(color: Colors.black, width: 1.0),
               ),
               label: Text("Name",style: TextStyle(
                   color: Colors.blueAccent,
                   fontSize: 15,
                   fontWeight: FontWeight.w600
               ),
               )
           ),
         ),
       ),
     );
   }

   launchSiteEditText()
   {
     return Container(
       width: MediaQuery.of(context).size.width > 500 ? 450 : MediaQuery.of(context).size.width,
       child: TextFormField(
         controller: launchSiteController,
         decoration: const  InputDecoration(
             focusedBorder: OutlineInputBorder(
               borderSide: BorderSide(color: Colors.black, width: 1.0),
             ),
             enabledBorder: OutlineInputBorder(
               borderSide: BorderSide(color: Colors.black, width: 1.0),
             ),
             label: Text("Launch Site",style: TextStyle(
                 color: Colors.blueAccent,
                 fontSize: 15,
                 fontWeight: FontWeight.w600
             ),
             )
         ),
       ),
     );
   }

   propertyStarsEditText()
   {
    return Container(
      height: 50,
      width: MediaQuery.of(context).size.width > 500 ? 450 : MediaQuery.of(context).size.width,
      color: Colors.grey[200],
      child: Center(
         child: RatingBar.builder(
           initialRating: _rating,
           minRating: 1,
           direction:  Axis.horizontal,
           allowHalfRating: false,
           unratedColor: Colors.amber.withAlpha(50),
           itemCount: 5,
           itemSize: 40.0,
           itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
           itemBuilder: (context, _) => const  Icon(
             Icons.star,
             color: Colors.amber,
           ),
           onRatingUpdate: (rating) {
             setState(() {
               print("rating ${rating}");
               _rating = double.parse(rating.toString());
             });
           },
           updateOnDrag: true,
         ),
      ),
    );
   }

   AddOrEditButton() {
     return GestureDetector(
       onTap: (){
         addProduct();
       },
       child: Container(
         width: MediaQuery.of(context).size.width > 500 ? 450 : MediaQuery.of(context).size.width,
         margin: EdgeInsets.only(left: 20,right: 20),
         height: 50,
         decoration: BoxDecoration(
           color: Colors.blueAccent,
           borderRadius: BorderRadius.circular(115)
         ),
         child: Center(
           child: Text(widget.postion == -1 ? "Add Product" : "Edit Product",
           style: TextStyle(
             color: Colors.white,
             fontSize: 20,
             fontWeight: FontWeight.w700
             ),
           ),
         ),
       ),
     );
   }

   getTime()
   {
     final dateTime = DateTime.now();

     if(dateTime.day < 10)
       {
         launchedAt = launchedAt + "0${dateTime.day.toString()}";
         sortTime = sortTime + "0${dateTime.day.toString()}";
       }
     else
       {
         launchedAt = launchedAt + "${dateTime.day.toString()}";
         sortTime = sortTime + "${dateTime.day.toString()}";
       }

     launchedAt = launchedAt + "-";

     if(dateTime.month < 10)
     {
       launchedAt = launchedAt + "0${dateTime.month.toString()}";
       sortTime = sortTime + "0${dateTime.month.toString()}";
     }
     else
     {
       launchedAt = launchedAt + "${dateTime.month.toString()}";
       sortTime = sortTime + "${dateTime.month.toString()}";
     }


     launchedAt = launchedAt + "-";

     if(dateTime.year < 10)
     {
       launchedAt = launchedAt + "0${dateTime.year.toString()}";
       sortTime = sortTime + "0${dateTime.year.toString()}";
     }
     else
     {
       launchedAt = launchedAt + "${dateTime.year.toString()}";
       sortTime = sortTime + "${dateTime.year.toString()}";
     }

     setState(() {
     });

     print("suri  ${sortTime}");

    print(launchedAt);
   }

   addProduct()
   {
     if(nameController.text == "")
       {
         EasyLoading.showToast("Please enter Name",
             dismissOnTap: true,
             duration: Duration(seconds: 1),
             toastPosition: EasyLoadingToastPosition.center);
         return;
       }


     if(launchSiteController.text == "")
     {
       EasyLoading.showToast("Please enter launch Site",
           dismissOnTap: true,
           duration: Duration(seconds: 1),
           toastPosition: EasyLoadingToastPosition.center);
       return;
     }

     if(_rating == "")
     {
       EasyLoading.showToast("Please enter stars",
           dismissOnTap: true,
           duration: Duration(seconds: 1),
           toastPosition: EasyLoadingToastPosition.center);
       return;
     }

     if(_selectedDate == null)
       {
         EasyLoading.showToast("Please pick time",
             dismissOnTap: true,
             duration: Duration(seconds: 1),
             toastPosition: EasyLoadingToastPosition.center);
         return;
       }



     String time = "${_selectedDate ==null ? "" : _selectedDate!.day < 10 ? "0${_selectedDate!.day.toString()}" : _selectedDate!.day.toString()}-${_selectedDate ==null ? "" :  _selectedDate!.day < 10 ? "0${_selectedDate!.month.toString()}" :  _selectedDate!.month.toString()}-${_selectedDate ==null ? "" :  _selectedDate!.day < 10 ? "${_selectedDate!.year.toString()}" : _selectedDate!.year.toString()}";

     MyModel model = new MyModel(nameController.text, time, launchSiteController.text, _rating.toString(), sortTime);

     print(model.name.toString());



     if(widget.postion == -1)
       {
         context.read<MyModelListWrapper>().add(model);
       }
     else
       {
         context.read<MyModelListWrapper>().editModelNumber(widget.postion,model);
       }

    Navigator.pop(context);
   }

   _selectDate(BuildContext context) async {
     DateTime? newSelectedDate = await showDatePicker(
         context: context,
         initialDate: _selectedDate ?? DateTime.now(),
         firstDate: DateTime(1900),
         lastDate: DateTime(2040),
          builder: (BuildContext context, Widget? child) {

           print("hello suri");
           return Theme(
             data: ThemeData.dark().copyWith(
               colorScheme: ColorScheme.dark(
                 primary: Colors.deepPurple,
                 onPrimary: Colors.white,
                 surface: Color(0xffffcc33),
                 onSurface: Colors.black,
               ),
               dialogBackgroundColor: Colors.white,
             ), child: child!,
          //   child: child,
           );
         });

     if (newSelectedDate != null) {
       _selectedDate = newSelectedDate;
       _dateController
         ..text = DateFormat.Md().format(_selectedDate!)
         ..selection = TextSelection.fromPosition(TextPosition(
             offset: _dateController.text.length,
             affinity: TextAffinity.upstream));
     }

     setState(() {

     });
   }
}
