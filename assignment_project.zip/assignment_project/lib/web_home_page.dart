import 'package:assignment_project/add_or_property.dart';
import 'package:assignment_project/models/my_models.dart';
import 'package:assignment_project/my_model_list_wrapper.dart';
import 'package:assignment_project/screennavigation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class WebHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blueAccent,
        title: const Text("DashBoard",style: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.w600
        ),),
        actions: [
          IconButton(onPressed: ()
          {
            MyModel model = new MyModel("", "", "", "","");

            pushTo(context, AddOrProperty(-1,model));
          }, icon: const Icon(Icons.add),color: Colors.white,iconSize: 20,),
          const SizedBox(width: 10,)
        ],
      ),
      body: Consumer<MyModelListWrapper>(
        builder: (_,myModelsListWrapper,__)=> GridView.builder(
          shrinkWrap: true,
          itemCount: myModelsListWrapper.modelsList.length,
          physics: NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: MediaQuery.of(context).size.width > 800 ? MediaQuery.of(context).size.width > 1400 ? 3 : 2 : 1,
              crossAxisSpacing: 4.0,
              mainAxisSpacing: 4.0,
              mainAxisExtent: 70
          ),
          itemBuilder: (ctx, index) => ListTile(
            title:  Text('${myModelsListWrapper.modelsList[index].name}  ${myModelsListWrapper.modelsList[index].launchedAt}',maxLines: 1,
              style:const TextStyle(
                  fontSize: 15,
                  color: Colors.black,
                  fontWeight: FontWeight.w600
              ),),
            subtitle:  Row(
              children: [
                Text("${myModelsListWrapper.modelsList[index].popularity}", style: TextStyle(
                    color: Colors.black,
                    fontSize: 15,
                    fontWeight: FontWeight.w600
                ),),
                const  Icon(
                  Icons.star,
                  color: Colors.amber,
                  size: 18,
                ),
                Container(
                    child: Text(' ${myModelsListWrapper.modelsList[index].launchSite}  ${myModelsListWrapper.modelsList[index].launchSite}',maxLines: 1,
                      style:const TextStyle(
                          fontSize: 12,
                          color: Colors.black,
                          fontWeight: FontWeight.w600
                      ),
                    )
                ),
              ],
            ),
            leading: Container(
              height: 50,
              width: 50,
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.black,width: 1),
                  borderRadius: BorderRadius.circular(100)
              ),
              child: IconButton(
                icon: Icon(Icons.edit),color: Colors.black,onPressed: ()
              {
                pushTo(context, AddOrProperty(index,myModelsListWrapper.modelsList[index]));
              },
              ),
            ),
            trailing: Column(
              children: [
                Container(
                  width: 20,
                  child: IconButton(
                    icon: Icon(Icons.delete_forever),color: Colors.black,onPressed: () {
                    getAlietr(myModelsListWrapper,index,context);
                  },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }


  getAlietr(myModelsListWrapper,index,context) async
  {
    print("hello suri");
    return showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text("Show Alert Dialog Box"),
        content: Text("Do you really want to delete"),
        actions: <Widget>[
          FlatButton(
            onPressed: () {
              myModelsListWrapper.removeAt(index);
              Navigator.of(ctx).pop();
            },
            child: Text("Ok"),
          ),
        ],
      ),
    );
  }
}