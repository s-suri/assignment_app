import 'package:assignment_project/home_page.dart';
import 'package:assignment_project/models/my_models.dart';
import 'package:assignment_project/my_model_list_wrapper.dart';
import 'package:assignment_project/web_home_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:provider/provider.dart';
import 'package:flutter/foundation.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp());
  configLoading();
}

void configLoading() {
  EasyLoading.instance
    ..displayDuration = const Duration(milliseconds: 2000)
    ..indicatorType = EasyLoadingIndicatorType.fadingCircle
    ..loadingStyle = EasyLoadingStyle.dark
    ..indicatorSize = 45.0
    ..radius = 10.0
    ..progressColor = Colors.yellow
    ..backgroundColor = Colors.green
    ..indicatorColor = Colors.yellow
    ..textColor = Colors.yellow
    ..maskColor = Colors.blue.withOpacity(0.5)
    ..userInteractions = true
    ..toastPosition = EasyLoadingToastPosition.top
    ..dismissOnTap = false;

  // ..customAnimation = CustomAnimation();
}

class MyApp extends StatelessWidget {
  List<MyModel> modelsList = [];


  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
            create: (_) => MyModelListWrapper(modelsList),
        ),
      ],
      child: MaterialApp(
        builder: EasyLoading.init(),
        debugShowCheckedModeBanner: false,
        home: defaultTargetPlatform == TargetPlatform.android ? HomePage() : defaultTargetPlatform == TargetPlatform.iOS ? HomePage() : WebHomePage() ,
      ),
    );
  }
}