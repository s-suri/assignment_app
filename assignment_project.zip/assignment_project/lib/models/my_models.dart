
class MyModel {
  String name;
  String launchedAt;
  String launchSite;
  String popularity;
  String sortString;

  MyModel(this.name,this.launchedAt,this.launchSite,this.popularity,this.sortString);

  void edit(String newName,String newLaunchedAt,newLaunchSite, newPopularity,newSortString) {
    name = newName;
    launchedAt = launchedAt;
    launchSite = newLaunchSite;
    popularity = newPopularity;
    sortString = newSortString;
  }
}