import 'package:assignment_project/models/my_models.dart';
import 'package:flutter/material.dart';

class MyModelListWrapper with ChangeNotifier {
  List<MyModel> modelsList;

  MyModelListWrapper(this.modelsList);

  void add(MyModel model) {
    modelsList.add(model);
    notifyListeners();
  }

  void removeAt(int index)
  {
    modelsList.removeAt(index);
    notifyListeners();
  }

  void editModelNumber(int index,MyModel model){
    modelsList[index].edit(model.name,model.launchedAt,model.launchSite,model.popularity,model.sortString);
    notifyListeners();
  }
}